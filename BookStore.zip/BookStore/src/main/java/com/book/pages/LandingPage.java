package com.book.pages;

import org.openqa.selenium.By;
public class LandingPage {
	public By searchBox = By.xpath("//*[@id='woocommerce-product-search-field-0']");
	
	public By shop = By.xpath("//*[@id=\"menu-main-menu-1\"]/li[6]/a/span");
	
	public By enteer = By.xpath("//*[@id=\"woocommerce_product_search-3\"]/form/button");
	
	public By contact = By.xpath("//*[@id=\"menu-main-menu-1\"]/li[5]/a/span");
	
	public  By sortt = By.xpath("//*[@id=\"main\"]/header/div[2]/form/div/div/button/span");
	
	public By sortbylate = By.xpath("//*[@id=\"main\"]/header/div[2]/form/div/div/ul/li[2]/a");
	
	public By sortbypopu = By.xpath("//*[@id=\"main\"]/header/div[2]/form/div/div/ul/li[1]/a");
	
	public By sortbyinnc = By.xpath("//*[@id=\"main\"]/header/div[2]/form/div/div/ul/li[3]/a");
	
	public By sortdecc = By.xpath("//*[@id=\"main\"]/header/div[2]/form/div/div/ul/li[4]/a");
	
	public By addtocar = By.xpath("//*[@id=\"product-8721\"]/div[2]/form/button");
	
	public By viewCart = By.xpath("//*[@id=\"main\"]/div/div[1]/div[1]/div/a");
	
	public By toout = By.xpath("//*[@id=\"main-wrapper\"]/div[1]/div/div[4]/div/div/div/a");
	
	public By toLogin = By.xpath("//*[@id=\"main-wrapper\"]/header[1]/div[1]/div/div/div[2]/div[1]/a/span");
	
	public By toId = By.xpath("//*[@id=\"username\"]");
	
	public By toPass = By.xpath("//*[@id=\"password\"]");
	// pass = #$ffffff@
	
	public By loginButton = By.xpath("//*[@id=\"customer_login\"]/div[1]/form/p[3]/button");
	
	public By logoutButton = By.xpath("//*[@id=\"main-wrapper\"]/div[1]/div/div[1]/nav/ul/li[7]/a");
	
	}
