package com.book.pages;

public class ProductListing {
	public String productItem = "//*[@id=\"main\"]/div/div[1]/div[2]/ul/li/div[1]/a/span/img";
}
