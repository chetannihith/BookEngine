package com.bookstore.tests;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.bookstore.commonUtils.SeleniumMet;
import com.book.pages.LandingPage;
import com.book.pages.ProductListing;

import org.testng.annotations.AfterClass;

public class ProdSearchTests extends SeleniumMet{

	WebDriver driver;
	LandingPage landingPage = new LandingPage();
	ProductListing productListing = new ProductListing();
	
	@BeforeClass
	public void setup() {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	}
	
	@Test(priority =1)
	public void openBookSite() throws InterruptedException {
		driver.get("https://www.teltrilogy.com/");
		//driver.findElement(landingPage.searchBox).sendKeys("Anne Frank");
		Thread.sleep(3000);
		//clickOnAnElement(find(driver,By.xpath(String.format(landingPage.enteer))));
	}
	
	@Test(priority = 2)
	public void searchBook() throws InterruptedException {
		clickOnAnElement(driver.findElement(landingPage.shop));
		driver.findElement(landingPage.searchBox).sendKeys("Anne Frank");
		Thread.sleep(4000);
	}
	
	
	@Test(priority=3)
	public void selectItemAndAddToCart() {
		clickOnAnElement(find(driver,By.xpath(String.format(productListing.productItem, 4))));
	}

	@AfterClass
	public void tearDown() {
		driver.quit();
	}

}
