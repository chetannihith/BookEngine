package com.bookstore.ttest;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.bookstore.commonUtils.SeleniumMet;
import com.book.pages.LandingPage;
import com.book.pages.ProductListing;

import org.testng.annotations.AfterClass;

public class SeTests extends SeleniumMet{

	WebDriver driver;
	LandingPage landingPage = new LandingPage();
	ProductListing productListing = new ProductListing();
	
	@BeforeClass
	public void setup() {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	}
	
	@Test
	public void openBookSite() throws InterruptedException {
		driver.get("https://www.teltrilogy.com/");
		Thread.sleep(3000);
	}
	
	@Test(priority = 2)
	public void searchBook() throws InterruptedException {
		clickOnAnElement(driver.findElement(landingPage.shop));
		driver.findElement(landingPage.searchBox).sendKeys("Anne Frank");
		clickOnAnElement(driver.findElement(landingPage.enteer));
		Thread.sleep(4000);
	}
	
	@Test(priority=3)
	public void searchbook2() throws InterruptedException {
		clickOnAnElement(driver.findElement(landingPage.shop));
		driver.findElement(landingPage.searchBox).sendKeys("Swati");
		clickOnAnElement(driver.findElement(landingPage.enteer));
		Thread.sleep(4000);
	}
	
	@Test(priority = 4)
	public void contactUs() throws InterruptedException {
		clickOnAnElement(driver.findElement(landingPage.contact));
		Thread.sleep(4000);
	}
	
	@Test(priority = 5)
	public void sortinglate() throws InterruptedException {
		clickOnAnElement(driver.findElement(landingPage.shop));
		clickOnAnElement(driver.findElement(landingPage.sortt));
		clickOnAnElement(driver.findElement(landingPage.sortbylate));
		Thread.sleep(4000);
	}
	
	@Test(priority = 6)
	public void sortinginr() throws InterruptedException {
		clickOnAnElement(driver.findElement(landingPage.sortt));
		clickOnAnElement(driver.findElement(landingPage.sortbyinnc));
		Thread.sleep(4000);
	}
	

	@Test(priority = 7)
	public void sortingdecc() throws InterruptedException {
		clickOnAnElement(driver.findElement(landingPage.sortt));
		clickOnAnElement(driver.findElement(landingPage.sortdecc));
		Thread.sleep(4000);
	}
	

	@Test(priority = 8)
	public void sortingpopu() throws InterruptedException {
		clickOnAnElement(driver.findElement(landingPage.sortt));
		clickOnAnElement(driver.findElement(landingPage.sortbypopu));
		Thread.sleep(4000);;
	}
	
	
	
	@Test(priority=9)
	public void selectItemAndAddToCart() throws InterruptedException {
		clickOnAnElement(driver.findElement(landingPage.shop));
		Thread.sleep(2000);
		clickOnAnElement(find(driver,By.xpath(String.format(productListing.productItem, 4))));
		Thread.sleep(4000);
		clickOnAnElement(driver.findElement(landingPage.addtocar));
		Thread.sleep(2000);
		clickOnAnElement(driver.findElement(landingPage.viewCart));
		Thread.sleep(2000);
		clickOnAnElement(driver.findElement(landingPage.toout));
		Thread.sleep(4000);
	}
	
	@Test(priority = 10)
	public void login() throws InterruptedException {
		clickOnAnElement(driver.findElement(landingPage.toLogin));
		Thread.sleep(1000);
		clickOnAnElement(driver.findElement(landingPage.toId));
		driver.findElement(landingPage.toId).sendKeys("ppp");
		clickOnAnElement(driver.findElement(landingPage.toPass));
		driver.findElement(landingPage.toPass).sendKeys("#$ffffff@");
		clickOnAnElement(driver.findElement(landingPage.loginButton));
		Thread.sleep(4000);
		clickOnAnElement(driver.findElement(landingPage.logoutButton));
		Thread.sleep(3000);
	}
	
	
	@Test(priority = 11)
	public void loginwrong() throws InterruptedException {
		clickOnAnElement(driver.findElement(landingPage.toLogin));
		Thread.sleep(1000);
		clickOnAnElement(driver.findElement(landingPage.toId));
		driver.findElement(landingPage.toId).sendKeys("redt");
		clickOnAnElement(driver.findElement(landingPage.toPass));
		driver.findElement(landingPage.toPass).sendKeys("#00@");
		clickOnAnElement(driver.findElement(landingPage.loginButton));
	}

	@AfterClass
	public void tearDown() {
		driver.quit();
	}

}
