package com.bookstore.commonUtils;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
public class SeleniumMet {

	public void clickOnAnElement(WebElement e) {
		e.click();
	}

	public WebElement find(WebDriver d,By locator) {
		return d.findElement(locator);
	}
}
